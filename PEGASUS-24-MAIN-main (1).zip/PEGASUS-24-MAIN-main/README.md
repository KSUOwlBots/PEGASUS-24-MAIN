[![Build](https://github.com/KSUOwlBots/PING-15-MAIN/actions/workflows/main.yml/badge.svg)](https://github.com/KSUOwlBots/PING-15-MAIN/actions/workflows/main.yml)
