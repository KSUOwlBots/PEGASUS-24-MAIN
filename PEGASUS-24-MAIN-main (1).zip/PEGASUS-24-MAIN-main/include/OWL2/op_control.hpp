#pragma once
void intake_control();
void slapper_control();