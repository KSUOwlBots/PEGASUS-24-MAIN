#pragma once
#include "api.h"
extern pros::Motor intake;
extern pros::Motor slapper_left;
extern pros::Motor slapper_right;
extern pros::Motor WinchL;
extern pros::Motor WinchR;